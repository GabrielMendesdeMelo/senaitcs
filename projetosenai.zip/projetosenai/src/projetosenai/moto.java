/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetosenai;

/**
 *
 * @author aluno
 */

public class moto extends veiculo implements acoes{

    moto(String dono, String modelo, int ano) {
        this.setLiga(false);
        this.setTanque(50);
        this.setGasolina(13);
        
        this.setDono(dono);
        this.setModelo(modelo);
        this.setAno(ano);
    }

    @Override
   public void mostrar(){
       
       System.out.println(this.isLiga());
       System.out.println(this.getTanque());
       System.out.println(this.getGasolina());
       System.out.println(this.getDono());
       System.out.println(this.getModelo());
       System.out.println(this.getAno());
       System.out.println("=-=-=-=-=-=-=-=-=-=-=-");
   }
   
    @Override
    public void ligar() {

        if(this.isLiga() == true){
            System.out.println("esta ligado");
        }else{
            this.setLiga(true);
        }
        
    }

    @Override
    public void desligar() {

        if(this.isLiga() == false){
            System.out.println("esta desligado");
        }else{
            this.setLiga(false);
        }
        
    }

    @Override
    public void abastecer() {

        if(this.isLiga() == false){
            if(this.getGasolina() == this.getTanque()){
                System.out.println("o tanque esta cheio!");
            }else{
                System.out.println("abastecido");
                this.setGasolina(this.getTanque());
            }
        }else{
            System.out.println("desligue o veiculo");
        }
        
    }

    @Override
    public void acelerar() {

        if(this.isLiga() == false){
            System.out.println("esta desligado");
        }else{
            if(this.getGasolina() < 13){
                System.out.println("sem gasolina");
            }else{
                this.setGasolina(this.getGasolina() - 13);
                System.out.println("acelerando");
            }
        }
        
    }

    
}

    

