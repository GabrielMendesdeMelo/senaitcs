package projetosenai;

/**
 *
 * @author aluno
 */
public abstract class veiculo implements acoes {
    private boolean liga;
    private int tanque;
    private String dono;
    private String modelo;
    private int ano;
    private int gasolina;

    public int getGasolina() {
        return gasolina;
    }

    public void setGasolina(int gasolina) {
        this.gasolina = gasolina;
    }

    public boolean isLiga() {
        return liga;
    }

    public void setLiga(boolean liga) {
        this.liga = liga;
    }

    public int getTanque() {
        return tanque;
    }

    public void setTanque(int tanque) {
        this.tanque = tanque;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

   
}
