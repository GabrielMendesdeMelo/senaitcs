package projetosenai;

/**
 *
 * @author aluno
 */
public interface acoes {
    
    public void ligar();
    public void desligar();
    public void abastecer();
    public void acelerar();
    public void mostrar();
    
}
